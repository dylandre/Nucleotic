$('#login').click(function (e) {
  $('.bandeau').delay(1000).fadeIn(500);
  $('#header').delay(1000).fadeIn(500);
  $('.Connexion').fadeOut(1000);
})

$('#ForgPass').click(function (e) {
  $('.Connexion').fadeOut(1000);
  $('.ForgPass').delay(1000).fadeIn(500);
})

$('#Send').click(function (e) {
  $('.ForgPass').fadeOut(1000);
  $('.Connexion').delay(1000).fadeIn(500);
})

$('#register1').click(function (e) {
  $('.Register').delay(1000).fadeIn(500);
  $('.Connexion').fadeOut(1000);
})

$('#register2').click(function (e) {
  $('.Register').fadeOut(1000);
  $('.Connexion').delay(1000).fadeIn(500);
})

$('.Deco').click(function (e) {
  $('.Connexion').delay(1000).fadeIn(500);
  $('.bandeau').fadeOut(1000);
  $('#header').fadeOut(1000);
  $('.WinContact').fadeOut(1000);
  $('.WinRestau').fadeOut(1000);
  $('.WinSauv').fadeOut(1000);
  alert("Vous allez être déconnecté");
})

$('#Contact').click(function (e) {
  $('.WinContact').delay(500).fadeIn(500);
  $('.WinRestau').fadeOut(1000);
  $('.WinSauv').fadeOut(1000);
})

$('#Restau').click(function (e) {
  $('.WinRestau').delay(500).fadeIn(500);
  $('.WinContact').fadeOut(1000);
  $('.WinSauv').fadeOut(1000);
})

$('#Sauv').click(function (e) {
  $('.WinSauv').delay(500).fadeIn(500);
  $('.WinContact').fadeOut(1000);
  $('.WinRestau').fadeOut(1000);
})

$('.fa-bell').click(function (e) {
  alert("Vous avez 14 nouvelles notifications");
})

$('#button-connexion-1').click(function (e) {
  $('.panel-default-1').fadeOut(500);
  setTimeout(() => {$(e.target).attr("src","images/button-green.png")},500);
  $('.panel-default-1').fadeIn(2000);
})
$('#button-connexion-2').click(function (e) {
  $('.panel-default-2').fadeOut(500);
  setTimeout(() => {$(e.target).attr("src","images/button-green.png")},500);
  $('.panel-default-2').fadeIn(2000);
})
$('#button-connexion-3').click(function (e) {
  $('.panel-default-3').fadeOut(500);
  setTimeout(() => {$(e.target).attr("src","images/button-green.png")},500);
  $('.panel-default-3').fadeIn(2000);
})
